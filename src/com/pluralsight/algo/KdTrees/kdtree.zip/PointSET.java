/*package com.pluralsight.algo.KdTrees;

import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;*/


import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

public class PointSET {

    private final TreeSet<Point2D> points;

    public PointSET() {
        points = new TreeSet<>();
    }

    public boolean isEmpty() {
        return points.isEmpty();
    }

    public int size() {
        return points.size();
    }

    public void insert(Point2D p) {
        if (p == null) throw new IllegalArgumentException();

        if (!contains(p)) {
            points.add(p);
        }

    }

    public boolean contains(Point2D p) {
        if (p == null) throw new IllegalArgumentException();
        return points.contains(p);
    }

    public void draw() {

    }

    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null) throw new IllegalArgumentException();

        Point2D minPoint = new Point2D(rect.xmin(), rect.ymin());
        Point2D maxPoint = new Point2D(rect.xmax(), rect.ymax());

        List<Point2D> pointsInRect = new LinkedList<>();

        for (Point2D p : points.subSet(minPoint, true, maxPoint, true)) {
            // The y-coordinate has been validated by the minPoint & maxPoint
            if (p.x() >= rect.xmin() && p.x() <= rect.xmax()) {
                pointsInRect.add(p);
            }
        }
        return pointsInRect;
    }

    public Point2D nearest(Point2D p) {
        if (p == null) throw new IllegalArgumentException();

        if (isEmpty()) return null;

        Point2D nextHighestNearestPoint = points.ceiling(p);
        Point2D nextLowestNearestPoint = points.floor(p);

        if (nextHighestNearestPoint == null && nextLowestNearestPoint == null) return null;

        double distanceToHighestPoint = p.distanceTo(nextHighestNearestPoint);
        double distanceToLowestPoint = p.distanceTo(nextLowestNearestPoint);

        double distance = Math.min(distanceToHighestPoint, distanceToLowestPoint);

        Point2D minPoint = new Point2D(p.x(), p.y() - distance);
        Point2D maxPoint = new Point2D(p.x(), p.y() + distance);

        Point2D nearest = nextLowestNearestPoint;

        for (Point2D candidate: points.subSet(minPoint, true, maxPoint, true)) {
            if (p.distanceTo(candidate) < p.distanceTo(nearest)) {
                nearest = candidate;
            }
        }

        return nearest;

    }
}
